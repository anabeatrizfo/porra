import os
import sqlite3
import discord
from discord import app_commands
from discord.ext import commands

TOKEN = os.getenv("MTU1NDk0NzYzNjA5ODc2NDkwMQ.GV-rxK.BJyyHhy_3ikcP8t6a9x-CTQltKPLLPq4DTgTmc")
DATABASE = "recrutamento.db"

if not TOKEN:
    raise RuntimeError("A variável DISCORD_TOKEN não foi configurada no DialCloud.")

db = sqlite3.connect(DATABASE)
db.execute("PRAGMA foreign_keys = ON")
cursor = db.cursor()

cursor.execute("""CREATE TABLE IF NOT EXISTS config (id INTEGER PRIMARY KEY, meta INTEGER NOT NULL)""")
cursor.execute("INSERT OR IGNORE INTO config (id, meta) VALUES (1, 8)")
cursor.execute("""CREATE TABLE IF NOT EXISTS recrutadores (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL UNIQUE, discord_id TEXT)""")
cursor.execute("""CREATE TABLE IF NOT EXISTS recrutamentos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    recrutador_id INTEGER NOT NULL,
    nome_recrutado TEXT NOT NULL,
    id_recrutado TEXT NOT NULL UNIQUE,
    data TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (recrutador_id) REFERENCES recrutadores(id) ON DELETE CASCADE
)""")
db.commit()

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)

def pegar_meta():
    return cursor.execute("SELECT meta FROM config WHERE id=1").fetchone()[0]

def pegar_recrutadores():
    return cursor.execute("SELECT id, nome, discord_id FROM recrutadores ORDER BY nome COLLATE NOCASE").fetchall()

def contar_recrutamentos(recrutador_id):
    return cursor.execute("SELECT COUNT(*) FROM recrutamentos WHERE recrutador_id=?", (recrutador_id,)).fetchone()[0]

def eh_administrador(interaction):
    return interaction.user.guild_permissions.administrator

@bot.event
async def on_ready():
    try:
        comandos = await bot.tree.sync()
        print(f"BOT: {bot.user}")
        print("Bot conectado!")
        print(f"Comandos sincronizados: {len(comandos)}")
    except Exception as erro:
        print(f"Erro ao sincronizar comandos: {erro}")

class RecrutamentoModal(discord.ui.Modal):
    def __init__(self, recrutador_id):
        super().__init__(title="Novo Recrutamento")
        self.recrutador_id = recrutador_id
        self.nome_recrutado = discord.ui.TextInput(label="Nome da pessoa recrutada", placeholder="Exemplo: Carlos Silva", required=True, max_length=100)
        self.id_recrutado = discord.ui.TextInput(label="ID da pessoa recrutada", placeholder="Exemplo: 45872", required=True, max_length=30)
        self.add_item(self.nome_recrutado)
        self.add_item(self.id_recrutado)

    async def on_submit(self, interaction):
        nome = self.nome_recrutado.value.strip()
        id_pessoa = self.id_recrutado.value.strip()
        existe = cursor.execute("SELECT id FROM recrutamentos WHERE id_recrutado=?", (id_pessoa,)).fetchone()
        if existe:
            await interaction.response.send_message(f"❌ O ID `{id_pessoa}` já foi registrado.", ephemeral=True)
            return
        cursor.execute("INSERT INTO recrutamentos (recrutador_id, nome_recrutado, id_recrutado) VALUES (?, ?, ?)", (self.recrutador_id, nome, id_pessoa))
        db.commit()
        nome_recrutador = cursor.execute("SELECT nome FROM recrutadores WHERE id=?", (self.recrutador_id,)).fetchone()[0]
        total = contar_recrutamentos(self.recrutador_id)
        meta = pegar_meta()
        embed = discord.Embed(title="✅ Recrutamento registrado!", color=discord.Color.green())
        embed.add_field(name="👮 Recrutador", value=nome_recrutador, inline=False)
        embed.add_field(name="👤 Pessoa recrutada", value=nome, inline=False)
        embed.add_field(name="🆔 ID", value=id_pessoa, inline=False)
        embed.add_field(name="📊 Progresso", value=f"**{total}/{meta}**", inline=False)
        if total >= meta:
            embed.add_field(name="🏆 Status", value="**META CONCLUÍDA! ✅**", inline=False)
        else:
            embed.add_field(name="🎯 Faltam", value=f"**{meta-total} recrutamento(s)**", inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)

class EscolherRecrutador(discord.ui.Select):
    def __init__(self):
        recrutadores = pegar_recrutadores()
        opcoes = [discord.SelectOption(label=nome[:100], description=f"{contar_recrutamentos(recrutador_id)} recrutamento(s)", value=str(recrutador_id)) for recrutador_id, nome, discord_id in recrutadores]
        super().__init__(placeholder="Selecione o seu nome", options=opcoes[:25])

    async def callback(self, interaction):
        await interaction.response.send_modal(RecrutamentoModal(int(self.values[0])))

class MenuRecrutador(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=120)
        self.add_item(EscolherRecrutador())

@bot.tree.command(name="recrutar", description="Registrar uma pessoa recrutada")
async def recrutar(interaction: discord.Interaction):
    if not pegar_recrutadores():
        await interaction.response.send_message("❌ Ainda não existem recrutadores cadastrados.", ephemeral=True)
        return
    await interaction.response.send_message("👮 **Quem está fazendo o recrutamento?**\n\nSelecione seu nome abaixo:", view=MenuRecrutador(), ephemeral=True)

@bot.tree.command(name="adicionar-recrutador", description="Adicionar um novo recrutador")
@app_commands.describe(nome="Nome do recrutador", discord_id="ID do Discord do recrutador")
async def adicionar_recrutador(interaction: discord.Interaction, nome: str, discord_id: str):
    if not eh_administrador(interaction):
        await interaction.response.send_message("❌ Apenas administradores podem usar esse comando.", ephemeral=True)
        return
    try:
        cursor.execute("INSERT INTO recrutadores (nome, discord_id) VALUES (?, ?)", (nome.strip(), discord_id.strip()))
        db.commit()
    except sqlite3.IntegrityError:
        await interaction.response.send_message("❌ Já existe um recrutador com esse nome.", ephemeral=True)
        return
    await interaction.response.send_message(f"✅ **{nome}** foi adicionado aos recrutadores!\n🆔 ID: `{discord_id}`", ephemeral=True)

@bot.tree.command(name="remover-recrutador", description="Remover um recrutador")
@app_commands.describe(nome="Nome exato do recrutador")
async def remover_recrutador(interaction: discord.Interaction, nome: str):
    if not eh_administrador(interaction):
        await interaction.response.send_message("❌ Apenas administradores podem usar esse comando.", ephemeral=True)
        return
    resultado = cursor.execute("SELECT id FROM recrutadores WHERE nome=?", (nome.strip(),)).fetchone()
    if not resultado:
        await interaction.response.send_message("❌ Recrutador não encontrado.", ephemeral=True)
        return
    recrutador_id = resultado[0]
    cursor.execute("DELETE FROM recrutamentos WHERE recrutador_id=?", (recrutador_id,))
    cursor.execute("DELETE FROM recrutadores WHERE id=?", (recrutador_id,))
    db.commit()
    await interaction.response.send_message(f"🗑️ **{nome}** foi removido.", ephemeral=True)

@bot.tree.command(name="definir-meta", description="Alterar a meta de recrutamentos")
@app_commands.describe(quantidade="Quantidade necessária para atingir a meta")
async def definir_meta(interaction: discord.Interaction, quantidade: int):
    if not eh_administrador(interaction):
        await interaction.response.send_message("❌ Apenas administradores podem usar esse comando.", ephemeral=True)
        return
    if quantidade < 1:
        await interaction.response.send_message("❌ A meta precisa ser maior que 0.", ephemeral=True)
        return
    cursor.execute("UPDATE config SET meta=? WHERE id=1", (quantidade,))
    db.commit()
    await interaction.response.send_message(f"🎯 A meta agora é **{quantidade} recrutamentos**!", ephemeral=True)

@bot.tree.command(name="recrutadores", description="Ver todos os recrutadores")
async def recrutadores(interaction: discord.Interaction):
    lista = pegar_recrutadores()
    meta = pegar_meta()
    if not lista:
        await interaction.response.send_message("❌ Nenhum recrutador cadastrado.", ephemeral=True)
        return
    embed = discord.Embed(title="👥 RECRUTADORES", description=f"🎯 Meta atual: **{meta}**", color=discord.Color.blurple())
    for recrutador_id, nome, discord_id in lista:
        total = contar_recrutamentos(recrutador_id)
        status = "🏆 **META CONCLUÍDA**" if total >= meta else f"📊 **{total}/{meta}**"
        embed.add_field(name=f"👮 {nome}", value=f"🆔 `{discord_id}`\n{status}", inline=False)
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="ranking", description="Ver o ranking dos recrutadores")
async def ranking(interaction: discord.Interaction):
    lista = pegar_recrutadores()
    meta = pegar_meta()
    ranking_lista = [(nome, contar_recrutamentos(recrutador_id)) for recrutador_id, nome, discord_id in lista]
    ranking_lista.sort(key=lambda x: (-x[1], x[0].lower()))
    if not ranking_lista:
        await interaction.response.send_message("❌ Nenhum recrutador cadastrado.", ephemeral=True)
        return
    embed = discord.Embed(title="🏆 RANKING DE RECRUTADORES", description=f"🎯 Meta: **{meta}**", color=discord.Color.gold())
    medalhas = ["🥇", "🥈", "🥉"]
    for posicao, (nome, total) in enumerate(ranking_lista, start=1):
        icone = medalhas[posicao - 1] if posicao <= 3 else f"**{posicao}º**"
        status = " ✅" if total >= meta else ""
        embed.add_field(name=f"{icone} {nome}", value=f"**{total} recrutamento(s)**{status}", inline=False)
    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="historico", description="Ver os últimos recrutamentos")
@app_commands.describe(limite="Quantidade de registros para mostrar")
async def historico(interaction: discord.Interaction, limite: int = 10):
    if not eh_administrador(interaction):
        await interaction.response.send_message("❌ Apenas administradores podem usar esse comando.", ephemeral=True)
        return
    limite = max(1, min(limite, 20))
    registros = cursor.execute("""SELECT r.nome, x.nome_recrutado, x.id_recrutado, x.data FROM recrutamentos x JOIN recrutadores r ON r.id=x.recrutador_id ORDER BY x.id DESC LIMIT ?""", (limite,)).fetchall()
    if not registros:
        await interaction.response.send_message("📭 Nenhum recrutamento registrado.", ephemeral=True)
        return
    embed = discord.Embed(title="📋 HISTÓRICO DE RECRUTAMENTOS", color=discord.Color.blue())
    for recrutador, nome, id_pessoa, data in registros:
        embed.add_field(name=f"👮 {recrutador} → 👤 {nome}", value=f"🆔 ID: `{id_pessoa}`\n🕒 {data}", inline=False)
    await interaction.response.send_message(embed=embed, ephemeral=True)

bot.run(TOKEN)
