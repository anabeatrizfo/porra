========================================
BOT DE RECRUTAMENTO - DISCORD
========================================

ARQUIVOS:
- bot.py
- requirements.txt
- README.txt

COMANDOS:
- /recrutar
- /adicionar-recrutador
- /remover-recrutador
- /definir-meta
- /recrutadores
- /ranking
- /historico

CONFIGURAÇÃO NO DIALCLOUD:
1. Envie bot.py e requirements.txt.
2. Instale as dependências:
   pip install -r requirements.txt
3. Crie a variável de ambiente DISCORD_TOKEN.
4. Coloque nela o TOKEN do seu bot do Discord Developer Portal.
5. Inicie com:
   python bot.py

IMPORTANTE:
- Nunca coloque o Token diretamente no código.
- O banco recrutamento.db é criado automaticamente.
- Use armazenamento persistente no DialCloud para manter os dados após reinicializações.

EXEMPLO:
/adicionar-recrutador nome: João discord_id: 123456789
/definir-meta quantidade: 8
/recrutar

O mesmo ID de pessoa recrutada não pode ser registrado duas vezes.
